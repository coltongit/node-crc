module.exports = require('./es6/crc16xmodem').default;
