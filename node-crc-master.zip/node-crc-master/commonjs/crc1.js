module.exports = require('./es6/crc1').default;
