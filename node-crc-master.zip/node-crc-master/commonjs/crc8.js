module.exports = require('./es6/crc8').default;
