module.exports = require('./es6/crc16').default;
