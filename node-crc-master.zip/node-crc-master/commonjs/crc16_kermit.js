module.exports = require('./es6/crc16kermit').default;
