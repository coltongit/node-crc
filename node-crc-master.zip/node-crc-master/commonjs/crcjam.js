module.exports = require('./es6/crcjam').default;
