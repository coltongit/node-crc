module.exports = require('./es6/crc17_kermit').default;
