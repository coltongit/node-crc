module.exports = require('./es6/crc24').default;
