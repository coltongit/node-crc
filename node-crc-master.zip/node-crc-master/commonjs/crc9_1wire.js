module.exports = require('./es6/crc9_1wire').default;
