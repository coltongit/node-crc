# commonjs

These files are proxy files to ES6 modules. They are compiled into the `lib` folder to avoid breaking original CRC module CommonJS structure.
