module.exports = require('./es6/crc32').default;
