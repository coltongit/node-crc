module.exports = require('./es6/crc16ccitt').default;
