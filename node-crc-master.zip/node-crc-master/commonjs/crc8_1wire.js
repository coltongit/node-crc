module.exports = require('./es6/crc81wire').default;
