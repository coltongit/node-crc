import crc32 from 'crc/crc32';
import crc from 'crc';

// eslint-disable-next-line no-console
console.log(crc32('hello world'), crc.crc32('hello world'));
